Sebelum Menajalankan Tools Install ini
[+] Gunakan Python 3
[+] Pip install paramiko
[+] pip install request
[+] pip install Colorama
